# list_review.py
# list 자료형 복습문제

'''
키보드로 값을 입력받고 요구대로 처리한 다음 출력 확인하시오.
입력내용 :
    번호 : 12 (sno : int)
    이름 : 황지니 (sname : str)
    국어 : 85 (kor : int)
    영어 : 85 (eng : int)
    수학 : 85 (mat : int)

처리내용 :
    입력받은 값들을 리스트(sungjuk_list)에 저장하시오.
    index 0 : sno, index 1 : sname, index 2 : kor, index 3 : eng,
    index 4 : mat
    index 5 : 3과목의 총점 (int)
    index 6 : 3과목의 평균 (float)

출력내용 : format() 사용함
    12번 황지니의 총점은 255 점, 평균은 85.0 점.
    국어 : 85 점, 영어 : 85 점, 수학 : 85 점입니다.

'''
def func():
    sno = int(input('번호 : '))
    sname = input('이름 : ')
    kor = int(input('국어 : '))
    eng = int(input('영어 : '))
    mat = int(input('수학 : '))

    sungjuk_list = [sno, sname, kor, eng, mat]

    tot = kor + eng + mat
    avg = tot / 3

    sungjuk_list.append(tot)
    sungjuk_list.append(avg)

    print('{}번 {}의 총점은 {} 점, 평균은 {:0.2f} 점.'.format(sungjuk_list[0], \
                sungjuk_list[1], sungjuk_list[5], sungjuk_list[6]))
    print('국어 : {} 점, 영어 : {} 점, 수학 : {} 점입니다.'.format(sungjuk_list[2], \
                sungjuk_list[3], sungjuk_list[4]))