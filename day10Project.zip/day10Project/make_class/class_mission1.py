# class_mission1.py
# 클래스 실습문제 1

'''
클래스 작성 : 클래스명은 Book
클래스 멤버변수 : 기본 private 처리함
    title = '제목없음'
    author = '작자미상'
    price = 0
    tex = 0.05
매개변수 없는 기본생성자와 기본소멸자 작성함
클래스 멤버함수 :
    info() => 필드 값들을 하나의 문장으로 만들어서 리턴함. format() 활용
    각 필드에 대한 set_필드명() => 전달받은 값으로 변경하도록 처리
    각 필드에 대한 get_필드명() => 해당 필드값 리턴 처리

클래스 사용 :
    => Book 클래스에 대한 객체 생성
    => 레퍼런스를 이용한 set 메소드로 객체의 필드값 변경하고
    => info() 메소드 출력 확인
    => get 메소드 이용해서 도서가격과 할인율이 적용된 도서금액을 계산 출력
       도서금액 = 도서가격 + (도서가격 * 부가세율)

'''
class Book:
    __title = '제목없음'
    __author = '작자미상'
    __price = 0
    __tex = 0.05

    def __init__(self):  # 기본생성자임, 생성자는 수정할 수 있음
        print('Book 클래스 기본생성자 작동됨')

    def __del__(self):  # 기본소멸자임. 수정할 수 없음
        print('Book 클래스 인스턴스 소멸됨.')
    
    def info(self):
        # return '도서제목 : {}, 저자 : {}, {}원, 부가세 : {} %'\
        #     .format(self.__title, self.__author, self.__price, self.__tex)
        return f'도서제목 : {self.__title}, 저자 : {self.__author}, {self.__price}원, 부가세 : {self.__tax}'

    def set_title(self, title):
        self.__title = title

    def set_author(self, author):
        self.__author = author

    def set_price(self, price):
        self.__price = price

    def set_tex(self, tex):
        self.__tex = tex

    def get_title(self):
        return self.__title

    def get_author(self):
        return self.__author

    def get_price(self):
        return self.__price

    def get_tex(self):
        return self.__tex



# 클래스 사용
# 레퍼런스변수 = 클래스객체생성구문
# 생성된 객체(인스턴스)의 주소를 저장하는 변수를 레퍼런스라고 함
bref = Book()   # 객체 생성
# print(bref.__title)  # private 이므로 접근 불가능 : 에러 발생함
print(bref.info())  # 메소드 사용법 1 : 일반적인 사용법
print(Book.info(bref))  # 메소드 사용법 2 : 파이썬만 제공

bref.set_title('파이썬 내꺼 만들기')
bref.set_author('홍길동')
bref.set_price(35000)
bref.set_tex(0.1)

print(bref.info())

bookPrice = bref.get_price() + (bref.get_price() * bref.get_tex())
print('도서금액 : ', bookPrice)


