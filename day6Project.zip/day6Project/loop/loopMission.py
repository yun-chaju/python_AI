# loopMission.py

# 리스트 안의 튜플아이템의 값들에 대해
# 둘 중의 큰값과 작은값을 분류해서 출력처리

# 방법 1 : 조건식 직접 작성
def practice1():
    nlist = [(12, 45), (90, 32), (56, 19)]
    # for 문 안의 if else 문 사용
    for (first, second) in nlist:
        if first > second:
            max = first  # 큰 값 저장
            min = second # 작은값 저장
        else:
            max = second  # 큰 값 저장
            min = first   # 작은값 저장

        print(f'큰값 : {max}, 작은값 : {min}')

# 방법 2: 내장함수 이용
def practice2():
    nlist = [(12, 45), (90, 32), (56, 19)]
    # for 문 안의 if else 문 사용
    for (first, second) in nlist:
        tmax = max(first, second)
        tmin = min(first, second)

        print(f'큰값 : {tmax}, 작은값 : {tmin}')

# 활용 실습 : 조건식 직접 작성
# 리스트 안의 군집아이템들이 가진 값들 중 각각 가장 큰 값을 골라 내서
# 별도의 리스트에 저장 처리하고 출력 확인
def practice3():
    lists = [[43, 1, 20], (22, 41, 10, 73), {12, 32, 45, 3, 9}]
    max_list = []

    for item in lists: # 각 아이템별 큰 값 골라내서 max_list에 저장하기 처리
        print(item, type(item))
        max_value = 0  # 큰 값 기록할 변수 준비
        for n in item:
            if max_value < n:  # 저장된 값보다 비교값이 크다면
                max_value = n  # 큰 값을 바꿔 저장함
        max_list.append(max_value)  # 각 아이템별 큰값을 리스트에 추가함

    print(max_list)

# 내장함수 max(iterable) 사용 가능함
def practice4():
    lists = [[43, 1, 20], (22, 41, 10, 73), {12, 32, 45, 3, 9}]
    max_list = []

    for item in lists: # 각 아이템별 큰 값 골라내서 max_list에 저장하기 처리
        print(item, type(item))
        max_list.append(max(item))  # 각 아이템별 큰값을 리스트에 추가함

    print(max_list)

# while 문 실습문제

'''
아래의 작성된 for문을 while문으로 변경하시오.

sungjuk_list = [[12, '홍길동', 98], [15, '김유신', 87], [23, '황지니', 45]]

for student in sungjuk_list:
    if(student[2] >= 60):
        print('{}번 {} 학생은 합격입니다.'.format(student[0], student[1]))
    else:
        print('{}번 {} 학생은 불합격입니다.'.format(student[0], student[1]))
'''
def practice_while():
    sungjuk_list = [[12, '홍길동', 98], [15, '김유신', 87], [23, '황지니', 45]]

    # for student in sungjuk_list:
    #     if (student[2] >= 60):
    #         print('{}번 {} 학생은 합격입니다.'.format(student[0], student[1]))
    #     else:
    #         print('{}번 {} 학생은 불합격입니다.'.format(student[0], student[1]))

    # 1. while 문으로 변경
    print('while 문으로 변경한 경우 -----------------------------')
    idx = 0
    while idx < len(sungjuk_list):
        student = sungjuk_list[idx]
        idx += 1
        if (student[2] >= 60):
            print('{}번 {} 학생은 합격입니다.'.format(student[0], student[1]))
        else:
            print('{}번 {} 학생은 불합격입니다.'.format(student[0], student[1]))


# 2. for 문 안에 continue 를 사용해서 합격정보만 출력되게 처리하시오.
def practice_continue1():
    sungjuk_list = [[12, '홍길동', 98], [15, '김유신', 87], [23, '황지니', 45]]

    print('for 에 continue 적용한 경우 -----------------------------')
    for student in sungjuk_list:
        if student[2] < 60:
            continue
        print('{}번 {} 학생은 합격입니다.'.format(student[0], student[1]))

# 3. while 문 안에 continue 를 사용해서 합격정보만 출력되게 처리하시오.
def practice_continue2():
    sungjuk_list = [[12, '홍길동', 98], [15, '김유신', 87], [23, '황지니', 45]]

    print('while 에 continue 적용한 경우 -----------------------------')
    idx = 0
    while idx < len(sungjuk_list):
        student = sungjuk_list[idx]
        idx += 1
        if student[2] < 60:
            continue
        print('{}번 {} 학생은 합격입니다.'.format(student[0], student[1]))

# 4. 간단 if 문으로 변경 처리하시오.
def practice_short_if():
    sungjuk_list = [[12, '홍길동', 98], [15, '김유신', 87], [23, '황지니', 45]]

    for student in sungjuk_list:
        print(f'{student[0]}번 {student[1]} 학생은 합격입니다.' \
                if(student[2] >= 60) else \
            f'{student[0]}번 {student[1]} 학생은 불합격입니다.')

# ----------------------------------------------------------

import random

# 랜덤 : 임의의 숫자(랜덤값)를 발생시키고자 할 때
# random 모듈이 제공하는 함수를 사용할 수 있음

def test_random():
    print('임의의 랜덤값 : ', random.random())
    # 0.0 <= 랜덤값 < 1.0 범위의 임의의 실수형 숫자가 발생함

    print('랜덤값 확인 : ', random.randrange(1, 11))
    # start <= 랜덤값 < end 범위의 임의의 정수형 숫자가 발생함

'''
1부터 45까지의 임의의 정수 6개를 중복되지 않게 발생시켜서 저장하고 
오름차순정렬해서 출력되게 하시오.
'''
def display_lotto():
    numbers = set()  # numbers = {}
    # set 특징 : 중복허용 안 함(같은 값 두번 기록하지 않음), 저장 순서 없음

    while len(numbers) < 6:
        numbers.add(random.randrange(1, 46))

    lotto_numbers = list(numbers)  # set 을 list 로 바꿈
    lotto_numbers.sort(reverse=False)  # 오름차순 정렬 처리
    print('이번 주 로또 예상 번호 : ', lotto_numbers)

    # 참고
    print(lotto_numbers.sort())
    # sort() 는 리스트 내부를 정렬함. 반환값 없는 함수임
    # None 을 리턴함








