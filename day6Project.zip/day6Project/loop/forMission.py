# forMission.py
# 리스트 안의 리스트를 반복문으로 다루기 실습문제

'''
키보드로 값들을 입력받아 리스트에 저장한 다음, 각 아이템(요소)별로
저장된 값들을 출력 처리하시오.
리스트변수 : product_list
** 입력과 처리를 3번 반복 실행되게 함 : for 문 안에서 작성하면 됨
입력 내용 :
    0번째에 기록할 제품정보를 입력하세요. -------------
    제품번호 : 12 (pno : int)
    제품명 : 갤럭시s21 (pname : str)
    가격 : 1200000 (price : int)
    부가세 : 0.1 (tex : float)
    구매수량 : 10 (amount : int)
처리 내용 :
    입력받은 값을 리스트에 저장함 : 5개의 값들을 하나의 아이템으로 저장함

    # 추가함
    구매가격(total_price : float)을 계산해서, 각 아이템별로 구매수량 다음에 추가 저장함.
    구매가격 = (가격 + (가격 * 부가세)) * 구매수량

** 출력 for 문 따로 작성함
출력 내용 : 리스트의 각 아이템별로 값들을 꺼내서 출력되게 함
        인덱스 활용함.
    0번째 제품정보 -------------------
    제품번호 : 12
    제품명 : 갤럭시s21
    가격 : 1200000
    부가세 : 0.1
    구매수량 : 10
    구매가격 : 13200000 (정수형으로 출력되게 함)  # 추가 출력 처리함
    1번째 제품정보 -------------------
    제품번호 : 27
    제품명 : 갤럭시s21
    가격 : 1200000
    부가세 : 0.1
    구매수량 : 5
    2번째 제품정보 -------------------
    제품번호 : 34
    제품명 : 갤럭시s21
    가격 : 1200000
    부가세 : 0.1
    구매수량 : 7
'''
def product_process():
    # 리스트 생성
    product_list = []

    # 입력받아 리스트에 저장 처리 : 3번 반복
    for idx in range(3):
        print(idx, '번째에 기록할 제품정보를 입력하세요. --------------------')
        pno = int(input('제품번호 : '))
        pname = input('제품명 : ')
        price = int(input('가격 : '))
        tex = float(input('부가세 : '))
        amount = int(input('구매수량 : '))

        # 리스트에 리스트 형태로 저장함
        product_list.append([pno, pname, price, tex, amount])

        # 구매가격 계산해서 리스트에 추가 저장함
        total_price = (price + (price * tex)) * amount
        product_list[idx].append(total_price)

    # 리스트에 저장된 요수 출력 확인
    for idx in range(len(product_list)):
        print(idx, '번째 제품정보', '--------------------------')
        pno, pname, price, tex, amount, total_price = product_list[idx]
        print('제품번호 : ', pno)
        print('제품명 : ', pname)
        print('가격 : ', price)
        print('부가세 : ', tex)
        print('구매수량 : ', amount)
        print('구매가격 : ', int(total_price))


# 함수 실행 -------------------------------
if __name__ == '__main__':
    product_process()