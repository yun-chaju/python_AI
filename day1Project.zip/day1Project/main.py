# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.

def test_function():  # 함수 정의(생성)
    a = 1
    b = '1'
    c = 1.1
    d = True
    e = 99999999999999999999999999999999999999999999999
    print(type(a), type(b), type(c), type(d), type(e))

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('PyCharm')
    a = '안녕'
    b = '하세요'
    print(a + b)
    test_function()  # 함수 실행
    print('main 종료')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
