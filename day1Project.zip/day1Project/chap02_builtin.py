# chap02_builtin.py
# 파이선이 제공하는 내장함수 : 기본으로 제공됨
# 별도로 import 선언하지 않고 바로 사용함
# max, min, type, len, range, str, int, float, print, input 등

# type(값 또는 변수명) : 값의 자료형을 리턴
a = 12
b = 'text'
c = 1 + 4j
print(type(a), type(b), type(c))

# len(값 또는 변수) : 길이(저장된 값의 갯수) 리턴
d = 'abcd'
e = [1, 2, 3, 4, 5]
print(len(d), len(e))

# max(값들 또는 변수) : 최대값(가장 큰 값), min() : 최소값(가장 작은 값)
print(max('abcdefg'))
print(max('123456789'))
print(min('abcdefg'))
print(min('123456789'))
