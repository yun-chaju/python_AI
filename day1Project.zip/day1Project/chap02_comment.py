# chap02_comment.py
# 한 줄 주석은 앞에 '#' 기호 붙임

'''
파이선의 여러줄 주석문(comment)는
작은 또는 큰 따옴표를 앞뒤에 3개씩 표시하면 됨
'''

"""
파이선에서는 single quotation 과 double quotation 은 동일하게 취급됨
둘 중 편한 것을 사용하면 됨
"""

print(abs(-10))
