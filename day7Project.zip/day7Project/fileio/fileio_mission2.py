# fileio_mission2.py
# 파일 입출력 실습문제2

'''
파이썬으로 간단 메모장을 만들어서 작성한 내용을 파일에 저장하도록
코드를 구현하시오.
=> prompt_menu 출력 구문이 반복해서 실행되게 함
=> 반복문 내에서 번호를 입력받아서, 각 번호에 대한 처리내용이 작동되게 함
=> 4 가 입력되면 반복을 종료시킴
=> 반복이 종료되면, '파이썬 메모장을 종료합니다.' 출력하고 프로그램 종료함

=> 번호를 입력받아서,
1 입력시 : '내용을 입력하세요' 출력하고, 여러 줄로 키보드 입력이 작동되게 함
        문자열 변수(contents : str)에 한 줄의 입력내용을
        합치기(+ : concatenation) 처리함, 입력을 반복되게 함
        종료 조건은 '--end--' 가 입력되면 반복 종료됨
2 입력시 : 저장할 파일명 : 파일명 입력함
    => 파일에 기록 저장함
3 입력시 : 열기할 파일명 : 파일명 입력함
    => 파일의 내용을 읽어와서 출력함
4 입력시 : 메뉴 출력 반복을 종료함
'''
def simple_memo():
    prompt_menu = '''
    파이썬 메모장이 실행되었습니다.\n
    1. 새로 만들기
    2. 저장하기
    3. 불러오기
    4. 끝내기
    '''

    while True:
        print(prompt_menu)
        no = input('번호 선택 : ')

        if (no == '1'):
            print('내용을 입력하세요. \'--end--\' 입력시 내용 입력이 끝납니다.')
            contents = ''
            while True:
                in_str = input()
                if in_str == '--end--':
                    break
                contents += in_str + '\n'

        elif (no == '2'):
            fname = input('저장할 파일명 : ')
            f = open(fname, 'w', encoding='utf-8')
            f.write(contents)
            f.close()
            print('{} 파일에 성공적으로 저장되었습니다.'.format(fname))

        elif (no == '3'):
            fname = input('열기할 파일명 : ')
            f = open(fname, 'r', encoding='utf-8')
            contents = f.read()
            f.close()
            print(contents, end='')

        elif no == '4':
            break

        else:  # 입력값이 1, 2, 3, 4 가 아닌 경우
            print('잘못된 번호입니다. 다시 입력하세요.\n')

    print('파이썬 메모장을 종료합니다.')

# 프로그램 실행 ----------------------------------------------
if __name__ == '__main__':
    simple_memo()