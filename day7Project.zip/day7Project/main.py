# This is a start Python script.

import fileio.fileio_sample as fio
import os

if __name__ == '__main__':
    # fio.test_fwrite()
    # print(os.getcwd())  # cwd(current working directory : 현재 작업 디렉토리)
    # fio.test_fwrite2()
    # fio.test_fwrite3()
    # fio.test_osmodule()
    # fio.test_writelines()
    # fio.test_fread()
    # fio.test_fread2()
    # fio.test_binary_fio()
    # fio.test_binary_fio2()
    # fio.change_stdinout()
    fio.test_os()