# chap02_example1.py
# 복습문제 1

'''
키보드로 입력받아 요구조건대로 처리해서 결과를 출력되게 코드를 작성하시오.
입력 내용 :
 학생이름 입력 : 홍길동 (student_name : str)
 학생번호 입력 : 23 (student_no : int)
 국어점수 입력 : 80 (kor : int)
 영어점수 입력 : 90 (eng : int)
 수학점수 입력 : 100 (mat : int)
처리 내용 :
 국어, 영어, 수학 점수의 총합을 구해서 변수(tot : int)에 기록 저장
 총합으로 3과목의 평균을 구해서 변수(avg : float)에 기록 저장
출력 내용 :
 23번 홍길동의 과목총점은 280점이고 평균은 90.0점
'''

student_name = input('학생이름 입력 : ')
student_no = int(input('학생번호 입력 : '))
kor = int(input('국어점수 입력 : '))
eng = int(input('영어점수 입력 : '))
mat = int(input('수학점수 입력 : '))

tot = kor + eng + mat
avg = tot / 3

print('{}번 {}의 과목 총점은 {}점이고 평균은 {:0.2f}점'.format(student_no, \
                                             student_name, tot, avg))