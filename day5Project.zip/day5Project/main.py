# This is a project start Python script.

import contional.ifSample as cif
import contional.ifMission1
import contional.ifelse_mission2 as cm
import contional.ifelse_mission3 as cm3
import contional.mission as mm

# if __name__ == '__main__':
    # contional.ifSample.iftest()
    # cif.iftest()
    # cif.iftest2()
    # cif.testEven()
    # cif.testEven2()
    # cif.test_ifelse()
    # cif.test_in()
    # cif.checkPayment()
    # cif.checkPayment2()
    # cif.multi_if()
    # cif.shortCondition()
    # cif.shortCondition2()

    # if 실습문제
    # contional.ifMission1.practice1()

    # if else 실습문제
    # cm.practice2()
    # cm3.practice3()

    # 다중 if 실습문제
    # mm.practice4()


# 반복문 확인용 -----------------------------
import loop.loopSample as ls
import loop.loopMission as lm

if __name__ == '__main__':
    # ls.for_test1()
    # ls.for_list()
    # ls.for_tuple()
    # ls.for_set()
    # ls.for_str()
    # ls.for_sum()
    # ls.test_iterable()
    # ls.test_range()
    # ls.for_indexing()

    # 반복문 실습문제 실행확인
    # lm.practice1()
    lm.print_gugudan()




