# mission.py
# 다중 if 문 실습문제

'''
키보드로 학생이름, 점수를 입력받아, 학점을 처리해서 출력하시오.
입력 내용 :
  학생이름 : 홍길동 (name : str)
  점수 : 78 (score : int)
처리 내용 :
  <조건 처리> : 점수에 대한 등급(grade : str) 처리
  점수가  90 이상 등급 A
  점수가  80 이상 90 미만 등급 B
  점수가  70 이상 80 미만 등급 C
  점수가  60 이상 70 미만 등급 D
  점수가  60 미만 등급 F
출력 내용 :
  홍길동의 점수는 78 점이고, 등급은 C 입니다.
'''
def practice4():
    name = input('학생이름 : ')
    score = int(input('점수 : '))

    # if (score >= 90):
    #     grade = 'A'
    # elif (score >= 80 and score < 90):
    #     grade = 'B'
    # elif (score >= 70 and score < 80):
    #     grade = 'C'
    # elif (score >= 60 and score < 70):
    #     grade = 'D'
    # else:
    #     grade = 'F'

    grade = 'F'

    if (score >= 90):
        grade = 'A'
    elif (score >= 80):
        grade = 'B'
    elif (score >= 70):
        grade = 'C'
    elif (score >= 60):
        grade = 'D'

    print('{}의 점수는 {}점이고, 등급은 {} 입니다.'.format(name, score, grade))

# 중첩 if 실습문제
'''
정수 두 개를 키보드로 입력받아 요구조건대로 계산처리해서 출력하시오.
입력 내용 :
 첫번째 수 : 47 (num1 : int)
 두번째 수 : 23 (num2 : int)
처리 내용 :
 조건 1 ; 두 수 모두 양수여야 함
 조건 2 : 두 수 모두 양수이면, 두 수 모두 1 ~ 100 사이의 값인지 확인
        두 수의 합, 차, 곱, 몫, 나머지 계산해서 출력함
        1 ~ 100 사이의 값이 아니면, 1~100 사이의 값만 입력하세요. 출력
 양수가 아니면, 양수만 입력해야 됩니다. 출력

조건문 종료되면, 프로그램이 종료되었습니다. 출력함
'''
def practice5():
    num1 = int(input('첫번째 수 : '))
    num2 = int(input('두번째 수 : '))

    if (num1 > 0 and num2 > 0):
        # if ((num1 >= 1 and num1 <= 100) and (num2 >= 1 and num2 <= 100)):
        if (num1 <= 100 and num2 <= 100):
            print('{} + {} = {}'.format(num1, num2, num1 + num2))
            print('{} - {} = {}'.format(num1, num2, num1 - num2))
            print('{} * {} = {}'.format(num1, num2, num1 * num2))
            print('{} // {} = {}'.format(num1, num2, num1 // num2))
            print('{} % {} = {}'.format(num1, num2, num1 % num2))
        else:
            print('1~100사이의 값만 입력하세요.')
    else:
        print('양수만 입력해야 됩니다.')

    print('프로그램이 종료되었습니다.')

