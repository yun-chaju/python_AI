# loopMission.py
# 반복문 실습문제

'''
  키보드로 문자열을 입력받아서, 요구대로 처리하고 출력되게 하시오.
  실행 :
	문자열 입력 : apple (value : str)
  처리내용 :
  	for 문 사용 : 글자의 유니코드 출력이 반복되게 함
  출력 :
	a is unicode 97
    p is unicode 112
    p is unicode 112
    l is unicode 108
    e is unicode 101
'''
def practice1():
    value = input('문자열 입력 : ')

    for ch in value:
        print(f'{ch} is unicode {ord(ch)}')

# for in 문, range() 실습문제

'''
키보드로 구구단의 단수를 입력받아서, 해당 단의 구구단을 출력하시오.
입력 내용 :
    단수 : 3 (dan : int)
출력 내용 :
    3 * 1 = 3
    3 * 2 = 6
    3 * 3 = 9
    3 * 4 = 12
    3 * 5 = 15
    3 * 6 = 18
    3 * 7 = 21
    3 * 8 = 24
    3 * 9 = 27
'''
def print_gugudan():
    dan = int(input('단수 : '))

    for su in range(1, 10):
        print(f'{dan} * {su} = {dan * su}')