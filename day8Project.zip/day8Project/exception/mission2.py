# mission2.py
# 예외처리 실습문제 2

'''
try except finally를 사용해서 예외 발생 처리 구문을 작성하시오.
실행 내용 :
    가로와 세로크기를 입력받아서,
    사각형의 면적과 둘레를 계산해서 출력 처리
    가로와 세로 : 숫자형태로만 입력이 되어야 함
    => 입력받은 가로, 세로는 int 형으로 바꾸고 계산에 사용함
    => 사각형의 면적 : 가로 * 세로
    => 사각형의 둘레 : 2 * (가로 + 세로)
예외 처리 :
    입력받은 가로, 세로가 숫자형태가 아닐 때
    '숫자만 입력해야 됩니다.' 출력함
'''
def calculator():
    try:
        width = int(input('가로크기 : '))
        height = int(input('세로크기 : '))
        print(f'사각형의 가로 : {width}, 세로 : {height}')

        print(f'사각형의 면적 : {width * height}')
        print(f'사각형의 둘레 : {2 * (width + height)}')

    except:
        print('숫자만 입력해야 됩니다.')
    finally:
        print('도형 계산 처리 종료.')


# -----------------------------------------------------------
# try: except: else: finally: 로 변경하시오.
def calculator2():
    try:
        width = int(input('가로크기 : '))
        height = int(input('세로크기 : '))
    except:
        print('숫자만 입력해야 됩니다.')
    else:
        print(f'사각형의 가로 : {width}, 세로 : {height}')

        print(f'사각형의 면적 : {width * height}')
        print(f'사각형의 둘레 : {2 * (width + height)}')
    finally:
        print('도형 계산 처리 종료.')


# 함수 실행 -------------------------------------------------
if __name__ == '__main__':
    # calculator()
    calculator2()