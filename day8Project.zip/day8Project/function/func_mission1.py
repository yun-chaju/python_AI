# func_mission1.py
# 함수 만들고 사용하기 실습문제 1

'''
파이썬으로 함수를 이용하는 간단 계산기 만들기
함수 만들기 :
 tsum(x, y) 함수 :  2 개의 인자를 받아서 더하기 결과를 리턴
 tsub(x, y) 함수 :  2 개의 인자를 받아서 빼기 결과를 리턴
 tmul(x, y) 함수 :  2 개의 인자를 받아서 곱하기 결과를 리턴
 tdiv(x, y) 함수 :  2 개의 인자를 받아서 나누기한 몫과 나머지 결과를 리턴
함수 호출 : simple_calculator()
 try: except: else: finally: 로 구현하시오.
 키보드로 2개의 정수를 입력받아서, 각 함수 처리 결과를 출력되게 하시오.
 첫번째 정수 : 12
 두번째 정수 : 5
 12 + 5 = 17
 12 - 5 = 7
 12 * 5 = 60
 12 // 5 = 2  => 리턴받은 튜플의 0번째 값
 12 % 5 = 2 => 리턴받은 튜플의 1번째 값
'''
# 함수 만들기 ---------------------------------------
def tsum(x, y):
	return x + y

def tsub(x, y):
	return x - y

def tmul(x, y):
	return x * y

def tdiv(x, y):
	return x // y, x % y

# 함수 호출 ---------------------------------------------
def simple_calculator():
    try:
        first = int(input('첫번째 정수 : '))
        second = int(input('두번째 정수 : '))
    except Exception as msg:
        print('에러 발생 : ', msg)
    else:
        print(f'{first} + {second} = {tsum(first, second)}')
        print(f'{first} - {second} = {tsub(first, second)}')
        print(f'{first} * {second} = {tmul(first, second)}')
        tresult = tdiv(first, second)
        print(f'{first} // {second} = {tresult[0]}')
        print(f'{first} % {second} = {tresult[1]}')
    finally:
        print('간단 계산기 끝!')


# 실행 테스트 -------------------------------
if __name__ == '__main__':
    simple_calculator()

